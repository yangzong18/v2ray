<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2020/5/26
 * Time: 13:52
 */
class ModelPageOrder extends Model {
	public function getInfo($order_id){
		$query = $this->db->query("SELECT id FROM `" . DB_PREFIX . "page_order` WHERE order_id = '".(int)$order_id."' LIMIT 1");
		
		if($query->num_rows > 0){
			return true;
		}else{
			return false;
		}
		
	}
}