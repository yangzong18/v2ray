<?php
class ControllerExtensionModuleCiformbuilder extends Controller {
	public function index($setting) {
		static $module_row = 0;

		$this->load->model('page/form');

		$this->load->model('catalog/product');
		$product_id = intval($_REQUEST['product_id']);
		$product_info = $this->model_catalog_product->getProduct($product_id);

		$data['heading_title'] = $this->language->get('heading_title');

		if(isset($setting['page_form_id'])) {
			$page_form_id = $setting['page_form_id'];
		} else {
			$page_form_id = 0;
		}

		$page_form_info = $this->model_page_form->getPageForm($page_form_id);
		if ($page_form_info) {
			$this->document->addScript('catalog/view/javascript/jquery/magnific/jquery.magnific-popup.min.js');
			$this->document->addStyle('catalog/view/javascript/jquery/magnific/magnific-popup.css');
			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment.min.js');
			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/moment/moment-with-locales.min.js');
			$this->document->addScript('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.js');
			$this->document->addStyle('catalog/view/javascript/jquery/datetimepicker/bootstrap-datetimepicker.min.css');

			$data['page_form_id'] = $page_form_info['page_form_id'];
			$data['css'] = $page_form_info['css'];

			$data['text_select'] = $this->language->get('text_select');
			$data['button_upload'] = $this->language->get('button_upload');
			$data['text_loading'] = $this->language->get('text_loading');
			$data['text_none'] = $this->language->get('text_none');

			$data['heading_title'] = $page_form_info['title'];

			$data['description'] = html_entity_decode($page_form_info['description'], ENT_QUOTES, 'UTF-8');

			$data['bottom_description'] = html_entity_decode($page_form_info['bottom_description'], ENT_QUOTES, 'UTF-8');

			$data['fieldset_title'] = $page_form_info['fieldset_title'];
			$data['button_continue'] = ($page_form_info['submit_button']) ? $page_form_info['submit_button'] :  $this->language->get('button_continue');


			// Page Form Options
			$data['page_form_options'] = $this->model_page_form->getPageFormOptions($page_form_info['page_form_id']);
			$data['country_exists'] = $this->model_page_form->getPageFormOptionsCountry($page_form_info['page_form_id']);

			//---des---MaWei---Date:2019-01-12----Start--------
			$this->load->model('catalog/product');
			$this->load->model('tool/image');
			$productId = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
			$productInfo = $this->model_catalog_product->getProduct($productId);
			$proInfo['name'] = $productInfo['name'];
			$proInfo['image'] = $this->model_tool_image->resize($productInfo['image'], 150, 150);
			$data['proInfo'] = $proInfo;
	 		//---des---MaWei---Date:2019-01-12----End--------

			$this->load->model('localisation/country');
			$data['countries'] = $this->model_localisation_country->getCountries();


			$this->load->model('localisation/zone');
			$data['zones'] = $this->model_localisation_zone->getZonesByCountryId($this->config->get('config_country_id'));

			// Captcha
			if ($this->config->get($this->config->get('config_captcha') . '_status') && $page_form_info['captcha']) {
				$data['captcha'] = $this->load->controller('extension/captcha/' . $this->config->get('config_captcha'));
			} else {
				$data['captcha'] = '';
			}

			$data['module_row'] = $module_row++;
			//产品ID
			$data['product_id'] = $product_id;

			if(VERSION < '2.2.0.0') {
				if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/ciformbuilder.tpl')) {
					return $this->load->view($this->config->get('config_template') . '/template/module/ciformbuilder.tpl', $data);
				} else {
					return $this->load->view('default/template/module/ciformbuilder.tpl', $data);
				}
			} else if(VERSION == '2.2.0.0') {
				return $this->load->view('module/ciformbuilder', $data);
			} else{
				return $this->load->view('extension/module/ciformbuilder', $data);
			}
		}
	}
}