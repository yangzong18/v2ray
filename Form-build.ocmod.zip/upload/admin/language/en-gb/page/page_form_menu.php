<?php
// Heading
$_['text_formbuilder']      = 'Form Builder';
$_['text_page_form']      	= 'Forms';
$_['text_page_request']     = 'Form Page Submission';

$_['text_page_order']     = 'Order List';

