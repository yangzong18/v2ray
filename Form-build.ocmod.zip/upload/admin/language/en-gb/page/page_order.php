<?php
// Heading
$_['heading_title']      	 = 'Order Id List';
$_['text_success']       = 'Success: You have successfully imported your data!';
$_['text_del_success']       	 = 'Success: You have deleted order id!';
$_['text_list']          	 = 'Order Id List';
$_['text_add']           	 = 'Add Order Id';
$_['text_edit']          	 = 'Edit Order Id';


// Column
$_['column_id']          = 'Id';
$_['column_order_id']        	= 'Order Id';
$_['entry_upload']                          = 'File to be uploaded';
// Error
$_['error_warning']     	= 'Warning: Please check the form carefully for errors!';
$_['error_permission']  	= 'Warning: You do not have permission to modify Form Builders!';


// Error
$_['error_permission']                      = 'Warning: You do not have permission to modify Export/Import!';
$_['error_upload']                          = 'Uploaded spreadsheet file has validation errors!';
$_['error_worksheets']                      = 'Export/Import: Invalid worksheet names';
$_['error_upload_name']                     = 'Missing file name for upload';
$_['error_upload_ext']                      = 'Uploaded file has not one of the \'.xls\', \'.xlsx\' or \'.ods\' file name extensions, it might not be a spreadsheet file!';
$_['error_no_news']                         = 'No messages';
// Tabs
$_['tab_import']                            = 'Import';
$_['tab_export']                            = 'Export';
$_['tab_settings']                          = 'Settings';

// Button labels
$_['button_import']                         = 'Import';
$_['button_export']                         = 'Export';

?>