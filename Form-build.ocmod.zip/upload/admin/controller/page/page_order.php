<?php class ControllerPagePageOrder extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('page/page_order');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('page/page_buildtable');
		$this->model_page_page_buildtable->Buildtable();

		$this->load->model('page/page_order');

		$this->getList();
	}

	public function add() {
		$this->load->language('page/page_order');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('page/page_order');

		$this->getForm();
	}
	
	public function upload() {
		$this->load->language('page/page_order');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('page/page_order');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && ($this->validateUploadForm())) {
			if ((isset( $this->request->files['upload'] )) && (is_uploaded_file($this->request->files['upload']['tmp_name']))) {
				$file = $this->request->files['upload']['tmp_name'];
				if ($this->model_page_page_order->upload($file)) {
					$this->session->data['success'] = $this->language->get('text_success');
					$this->response->redirect($this->url->link('page/page_order', 'user_token=' . $this->session->data['user_token'], $this->ssl));
				}
				else {
					$this->error['warning'] = $this->language->get('error_upload');
					$this->error['warning'] .= "<br />\n".$this->language->get( 'text_log_details_2_1_x' );
				}
			}
		}
		
		$this->getForm();
	}
	
	protected function validateUploadForm() {
		if (!$this->user->hasPermission('modify', 'page/page_order')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if (!isset($this->request->files['upload']['name'])) {
			if (isset($this->error['warning'])) {
				$this->error['warning'] .= "<br /\n" . $this->language->get( 'error_upload_name' );
			} else {
				$this->error['warning'] = $this->language->get( 'error_upload_name' );
			}
		} else {
			$ext = strtolower(pathinfo($this->request->files['upload']['name'], PATHINFO_EXTENSION));
			if (($ext != 'xls') && ($ext != 'xlsx') && ($ext != 'ods')) {
				if (isset($this->error['warning'])) {
					$this->error['warning'] .= "<br /\n" . $this->language->get( 'error_upload_ext' );
				} else {
					$this->error['warning'] = $this->language->get( 'error_upload_ext' );
				}
			}
		}
		
		if (!$this->error) {
			return true;
		} else {
			return false;
		}
	}

	public function delete() {
		$this->load->language('page/page_order');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('page/page_order');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $page_form_id) {
				$this->model_page_page_order->deletePageOrder($page_form_id);
			}

			$this->session->data['success'] = $this->language->get('text_del_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('page/page_order', 'user_token=' . $this->session->data['user_token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'pd.title';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('page/page_order', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);

		$data['add'] = $this->url->link('page/page_order/add', 'user_token=' . $this->session->data['user_token'] . $url, true);
		$data['delete'] = $this->url->link('page/page_order/delete', 'user_token=' . $this->session->data['user_token'] . $url, true);

		$data['page_forms'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$page_form_total = $this->model_page_page_order->getTotalPageOrders();

		$results = $this->model_page_page_order->getPageOrders($filter_data);
		

		foreach ($results as $result) {
			$data['page_orders'][] = array(
				'id'  => $result['id'],
				'order_id' 		=> $result['order_id'],
				'edit'       	=> $this->url->link('page/page_order/edit', 'user_token=' . $this->session->data['user_token'] . '&id=' . $result['id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_id'] = $this->url->link('page/page_order', 'user_token=' . $this->session->data['user_token'] . '&sort=id' . $url, true);
		$data['sort_order_id'] = $this->url->link('page/page_order', 'user_token=' . $this->session->data['user_token'] . '&sort=order_id' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $page_form_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('page/page_order', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($page_form_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($page_form_total - $this->config->get('config_limit_admin'))) ? $page_form_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $page_form_total, ceil($page_form_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('page/page_order_list', $data));
	}

	protected function getForm() {
		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_form'] = !isset($this->request->get['id']) ? $this->language->get('text_add') : $this->language->get('text_edit');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['id'])) {
			$data['error_id'] = $this->error['id'];
		} else {
			$data['error_id'] = '';
		}

		if (isset($this->error['order_id'])) {
			$data['error_order_id'] = $this->error['order_id'];
		} else {
			$data['error_order_id'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('page/page_order', 'user_token=' . $this->session->data['user_token'] . $url, true)
		);
		
		$data['import'] = $this->url->link('page/page_order/upload', 'user_token=' . $this->session->data['user_token'], $url,true);

		$data['cancel'] = $this->url->link('page/page_order', 'user_token=' . $this->session->data['user_token'] . $url, true);


		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('page/page_order_form', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'page/page_form')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		foreach ($this->request->post['page_form_description'] as $language_id => $page_form_value) {
			if ((utf8_strlen($page_form_value['title']) < 2) || (utf8_strlen($page_form_value['title']) > 255)) {
				$this->error['title'][$language_id] = $this->language->get('error_title');
			}

			if ((utf8_strlen($page_form_value['meta_title']) < 3) || (utf8_strlen($page_form_value['meta_title']) > 255)) {
				$this->error['meta_title'][$language_id] = $this->language->get('error_meta_title');
			}
			
			if ((utf8_strlen($page_form_value['success_title']) < 2) || (utf8_strlen($page_form_value['success_title']) > 255)) {
				$this->error['success_title'][$language_id] = $this->language->get('error_success_title');
			}

			if(!empty($this->request->post['customer_email_status'])) {
				if ((utf8_strlen($page_form_value['customer_subject']) < 2) || (utf8_strlen($page_form_value['customer_subject']) > 255)) {
					$this->error['customer_subject'][$language_id] = $this->language->get('error_customer_subject');
				}

				$page_form_value['customer_message'] = str_replace('&lt;p&gt;&lt;br&gt;&lt;/p&gt;', '', $page_form_value['customer_message']);
				if ((utf8_strlen($page_form_value['customer_message']) < 25)) {
					$this->error['customer_message'][$language_id] = $this->language->get('error_customer_message');
				}
			}

			if(!empty($this->request->post['admin_email_status'])) {
				if(empty($this->request->post['admin_email'])) {
					$this->error['admin_email'] = $this->language->get('error_admin_email');
					$this->error['warning'] = $this->language->get('error_admin_email');
				}
				
				if ((utf8_strlen($page_form_value['admin_subject']) < 2) || (utf8_strlen($page_form_value['admin_subject']) > 255)) {
					$this->error['admin_subject'][$language_id] = $this->language->get('error_admin_subject');
				}

				$page_form_value['admin_message'] = str_replace('&lt;p&gt;&lt;br&gt;&lt;/p&gt;', '', $page_form_value['admin_message']);
				if ((utf8_strlen($page_form_value['admin_message']) < 25)) {
					$this->error['admin_message'][$language_id] = $this->language->get('error_admin_message');
				}
			}
		}

		if (isset($this->request->post['page_form_field'])) {
			foreach ($this->request->post['page_form_field'] as $row => $description) {
				if(isset($description['description'])) {
					foreach ($description['description'] as $language_id => $value) {
						if ((utf8_strlen($value['field_name']) < 1) || (utf8_strlen($value['field_name']) > 128)) {
							$this->error['field_name'][$row][$language_id] = $this->language->get('error_field_name');
						}
					}
				}

				if(isset($description['option_value']) && !in_array($description['type'], array('select', 'radio', 'checkbox')) ) {
					unset($this->request->post['page_form_field'][$row]['option_value']);
					unset($description['option_value']);
				}

				if(isset($description['option_value'])) {
					foreach ($description['option_value'] as $option_value_row => $option_value) {
						foreach ($option_value['page_form_option_value_description'] as $language_id => $option_value_description) {
							if ((utf8_strlen($option_value_description['name']) < 1) || (utf8_strlen($option_value_description['name']) > 128)) {
								$this->error['value_name'][$row][$option_value_row][$language_id] = $this->language->get('error_value_name');
							}
						}
					}
				}
			}
		}

		if ($this->request->post['page_form_seo_url']) {
			$this->load->model('design/seo_url');
			
			foreach ($this->request->post['page_form_seo_url'] as $store_id => $language) {
				foreach ($language as $language_id => $keyword) {
					if (!empty($keyword)) {
						if (count(array_keys($language, $keyword)) > 1) {
							$this->error['keyword'][$store_id][$language_id] = $this->language->get('error_unique');
						}						
						
						$seo_urls = $this->model_design_seo_url->getSeoUrlsByKeyword($keyword);
						
						foreach ($seo_urls as $seo_url) {
							if (($seo_url['store_id'] == $store_id) && (!isset($this->request->get['page_form_id']) || (($seo_url['query'] != 'page_form_id=' . $this->request->get['page_form_id'])))) {
								$this->error['keyword'][$store_id][$language_id] = $this->language->get('error_keyword');
								
								break;
							}
						}
					}
				}
			}
		}

		if ($this->error && !isset($this->error['warning'])) {
			$this->error['warning'] = $this->language->get('error_warning');
		}

		return !$this->error;
	}

		protected function validateDelete() {
			if (!$this->user->hasPermission('modify', 'page/page_form')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}	

	public function autocomplete() {
		$json = array();

		if (isset($this->request->get['filter_title'])) {
			if (isset($this->request->get['filter_title'])) {
				$filter_title = $this->request->get['filter_title'];
			} else {
				$filter_title = '';
			}

			$this->load->model('page/page_form');

			$filter_data = array(
				'filter_title' => $filter_title,
				'start'        => 0,
				'limit'        => 5
			);

			$results = $this->model_page_page_form->getPageForms($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'page_form_id'       => $result['page_form_id'],
					'title'              => strip_tags(html_entity_decode($result['title'], ENT_QUOTES, 'UTF-8')),
				);
			}
		}

		$sort_order = array();

		foreach ($json as $key => $value) {
			$sort_order[$key] = $value['title'];
		}

		array_multisort($sort_order, SORT_ASC, $json);

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}