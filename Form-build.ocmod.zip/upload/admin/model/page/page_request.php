<?php class ModelPagePageRequest extends Model {
	public function getPageRequest($page_request_id) {
		$query = $this->db->query("SELECT DISTINCT * FROM " . DB_PREFIX . "page_request WHERE page_request_id = '" . (int)$page_request_id . "'");

		return $query->row;
	}

	public function deletePageRequest($page_request_id) {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "page_request` WHERE page_request_id = '" . (int)$page_request_id . "'");
		$this->db->query("DELETE FROM `" . DB_PREFIX . "page_request_option` WHERE page_form_id = '" . (int)$page_request_id . "'");
	}

	public function getPageRequests($data = array()) {
		$sql = "SELECT *, CONCAT(pg.firstname, ' ', pg.lastname) AS customer FROM " . DB_PREFIX . "page_request pg WHERE pg.page_request_id > 0";

		if (!empty($data['filter_page_form_title'])) {
			$sql .= " AND pg.page_form_title LIKE '%" . $this->db->escape($data['filter_page_form_title']) . "%'";
		}

		if (!empty($data['filter_customer'])) {
			$sql .= " AND CONCAT(pg.firstname, ' ', pg.lastname) LIKE '%" . $this->db->escape($data['filter_customer']) . "%'";
		}

		if (!empty($data['filter_ip'])) {
			$sql .= " AND pg.ip = '" . $this->db->escape($data['filter_ip']) . "'";
		}

		if (!empty($data['filter_date_added'])) {
			$sql .= " AND DATE(pg.date_added) = DATE('" . $this->db->escape($data['filter_date_added']) . "')";
		}

		$sort_data = array(
			'customer',
			'pg.date_added',
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY pg.date_added";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}

	public function getTotalPageRequests() {
		$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "page_request");

		return $query->row['total'];
	}

	public function getPageRequestOptions($page_request_id) {
		$query = $this->db->query("SELECT `name`, `value`, `type` FROM " . DB_PREFIX . "page_request_option  WHERE page_request_id = '" . (int)$page_request_id . "' ORDER BY page_request_option_id ASC");

		return $query->rows;
	}
	
	
	public function download($data) {
		$expCellName = $data['cell_name'];
		$expTableData = $data['page_requests'];
		// we use our own error handler
		global $registry;
		$registry = $this->registry;
		
		// Use the PHPExcel package from https://github.com/PHPOffice/PHPExcel
		$cwd = getcwd();
		$dir = (strcmp(VERSION,'3.0.0.0')>=0) ? 'library/export_import' : 'PHPExcel';
		chdir( DIR_SYSTEM.$dir );
		require_once( 'Classes/PHPExcel.php' );
		PHPExcel_Cell::setValueBinder( new PHPExcel_Cell_ExportImportValueBinder() );
		chdir( $cwd );
		//标题
		$xlsTitle = iconv('utf-8', 'gb2312', $data['file_name']);
		//$xlsTitle 文件名称
		$fileName = date('Y-m-d').'download';
		$cellNum = count($expCellName);
		$dataNum = count($expTableData);

		$objPHPExcel = new \PHPExcel();
		$cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');
		
		//接下来就是写数据到表格里面去
		$objActSheet = $objPHPExcel->getActiveSheet();
		$startRow = 1;
		$tmp = [1];
		foreach ($tmp as $row) {
			foreach ($expCellName as $key => $value){
				
				$objActSheet->getColumnDimension($cellName[$key])->setAutoSize(true);#设置单元格宽度
				//这里是设置单元格的内容
				$objActSheet->setCellValue($cellName[$key].$startRow,$value);
				
				
			}
			$startRow++;
		}
		foreach ($data['page_requests'] as $row) {
			foreach ($expCellName as $key => $value){
				
				//这里是设置单元格的内容
				$objActSheet->setCellValue($cellName[$key].$startRow,$row[$value]);
				$objActSheet->getStyle($cellName[$key].$startRow)->getAlignment()->setWrapText(true);
				
			}
			$startRow++;
		}
		header('pragma:public');
		header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$xlsTitle.'.xlsx"');
		header("Content-Disposition:attachment;filename=$fileName.xlsx");
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		//文件通过浏览器下载
		$objWriter->save('php://output');
		
	}
}