<?php
class ModelPagePageOrder extends Model {
	public function upload( $filename) {
		// we use our own error handler
		global $registry;
		$registry = $this->registry;
		
		try {
			// we use the PHPExcel package from https://github.com/PHPOffice/PHPExcel
			$cwd = getcwd();
			$dir = version_compare(VERSION,'3.0','>=') ? 'library/export_import' : 'PHPExcel';
			chdir( DIR_SYSTEM.$dir );
			require_once( 'Classes/PHPExcel.php' );
			chdir( $cwd );
			
			// Memory Optimization
			if ($this->config->get( 'export_import_settings_use_import_cache' )) {
				$cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_to_phpTemp;
				$cacheSettings = array( ' memoryCacheSize '  => '16MB'  );
				PHPExcel_Settings::setCacheStorageMethod($cacheMethod, $cacheSettings);
			}
			
			// parse uploaded spreadsheet file
			$inputFileType = PHPExcel_IOFactory::identify($filename);
			$objReader = PHPExcel_IOFactory::createReader($inputFileType);
			$objReader->setReadDataOnly(true);
			$reader = $objReader->load($filename);
			$this->uploadOrder( $reader );
			
			return true;
		} catch (Exception $e) {
			$errstr = $e->getMessage();
			$errline = $e->getLine();
			$errfile = $e->getFile();
			$errno = $e->getCode();
			$this->session->data['export_import_error'] = array( 'errstr'=>$errstr, 'errno'=>$errno, 'errfile'=>$errfile, 'errline'=>$errline );
			if ($this->config->get('config_error_log')) {
				$this->log->write('PHP ' . get_class($e) . ':  ' . $errstr . ' in ' . $errfile . ' on line ' . $errline);
			}
			return false;
		}
	}
	
	protected function getCell(&$worksheet,$row,$col,$default_val='') {
		$col -= 1; // we use 1-based, PHPExcel uses 0-based column index
		$row += 1; // we use 0-based, PHPExcel uses 1-based row index
		$val = ($worksheet->cellExistsByColumnAndRow($col,$row)) ? $worksheet->getCellByColumnAndRow($col,$row)->getValue() : $default_val;
		if ($val===null) {
			$val = $default_val;
		}
		return $val;
	}
	
	
	protected function uploadOrder( &$reader ) {
		// 确定要读取的sheet，什么是sheet，看excel的右下角，真的不懂去百度吧
		$sheet = $reader->getSheet(0);
		$i = 0;
		$k = $sheet->getHighestRow();
		$order_id = [];
		for ($i=0; $i<$k; $i+=1) {
			$j = 1;
			$order_id[] = trim($this->getCell($sheet,$i,$j++));
		}
		$order_id = array_unique($order_id);
		
		$ids = '("'.implode('","',$order_id).'")';
		
		$query = $this->db->query("SELECT order_id FROM `". DB_PREFIX ."page_order` WHERE order_id in ".$ids);
		
		$temp = [];
		
		foreach ($query->rows as $row){
			$temp[] = $row['order_id'];
		}
		
		$order_id = array_unique($order_id);
		$sql = "INSERT INTO `". DB_PREFIX ."page_order` (order_id) VALUES ";
		$flag = false;
		foreach ($order_id as $id){
			if(!in_array($id,$temp)){
				$flag = true;
				$sql .= "('$id'),";
			}
		}
		$sql = substr($sql, 0, -1).';';
		if($flag){
			$this->db->query($sql);
		}
		
	}
	
	public function getTotalPageOrders(){
		$query = $this->db->query("SELECT COUNT(id) AS total FROM `" . DB_PREFIX . "page_order`");
		
		return $query->row['total'];
		
	}
	
	
	public function getPageOrders($data){
		$sql = "SELECT id,order_id FROM `" . DB_PREFIX . "page_order` WHERE 1 = 1 ";
		
		if (!empty($data['order_id'])) {
			$sql .= " AND order_id LIKE " . $this->db->escape($data['order_id']) . "%'";
		}
		
		$sort_data = array(
			'id',
			'order_id',
		);
		
		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY id";
		}
		
		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}
		
		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}
			
			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}
			
			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}
		
		$query = $this->db->query($sql);
		
		return $query->rows;
	}
	
	public function deletePageOrder($id) {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "page_order` WHERE id = '" . (int)$id . "'");
	}
	
	
	
}